package testScripts;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.testng.Assert;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import POM.Home;
import POM.Register;
import utilities.Browser;

public class CompulsoryFieldTest {

WebDriver driver=new FirefoxDriver();
	
	@BeforeMethod
	public void setUp()
	{
		Browser.start(driver);

	    driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);

		
		System.out.println("Test Case start.");
	}
	
	@AfterMethod
	public void tearDown()
	{
		System.out.println("Test Case End.");
		
		Browser.close(driver);
	}
	
	@Test
	public void CompulsoryField() throws InterruptedException
	{
		Home.QuickRegisterButton(driver).click();
		Thread.sleep(2000);
		Register.FirstName(driver).clear();
		Register.LastName(driver).sendKeys("xyz");
		Register.PinCode(driver).sendKeys("416005");
		
		String firstN=Register.FirstName(driver).getAttribute("value");
		String lastN=Register.FirstName(driver).getAttribute("value");
		String pincode=Register.FirstName(driver).getAttribute("value");
		
		if(firstN.length()<=0)
		{
			System.out.println("First Name is compulsory!");
			Assert.assertTrue(false);
		}
		if(lastN.length()<=0)
		{
			System.out.println("Last Name is compulsory!");
			Assert.assertTrue(false);
		}
		if(pincode.length()<=0)
		{
			System.out.println("Pincode is compulsory!");
			Assert.assertTrue(false);
		}
	
	}
	
}
