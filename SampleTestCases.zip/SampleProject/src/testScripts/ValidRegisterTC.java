package testScripts;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import POM.Home;
import POM.Register;
import utilities.Browser;

public class ValidRegisterTC {
	WebDriver driver=new FirefoxDriver();
	
	@BeforeMethod
	public void setUp()
	{
		Browser.start(driver);

	    driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);

		
		System.out.println("Test Case start.");
	}
	
	@AfterMethod
	public void tearDown()
	{
		System.out.println("Test Case End.");
		
		Browser.close(driver);
	}
	
	@Test
	public void validRegisterTest() throws InterruptedException
	{
		
	    Home.QuickRegisterButton(driver).click();
		Thread.sleep(2000);
		Register.CustomerRadioButton(driver).click();
		Register.FirstName(driver).sendKeys("abc");
		Register.LastName(driver).sendKeys("xyz");
		Register.PinCode(driver).sendKeys("416005");
		Register.Email(driver).sendKeys("abc@xyz.com");
		Register.Mobile(driver).sendKeys("9028347511");
		Register.AcceptConditionRadioButton(driver).click();
		Register.RegisterButton(driver).click();
		
		System.out.println("Registration done");
		
	}
	
	

}
