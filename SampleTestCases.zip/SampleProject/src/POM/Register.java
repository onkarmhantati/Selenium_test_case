package POM;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

public class Register {

	public static WebElement CustomerRadioButton(WebDriver dir)
	{
		return dir.findElement(By.xpath("//input[@ng-model='user.customerType'][@value='1']"));
	}
	
	public static WebElement TruckownerRadioButton(WebDriver dir)
	{
		return dir.findElement(By.xpath("//input[@ng-model='user.customerType'][@value='2']"));
	}
	
	public static WebElement FirstName(WebDriver dir)
	{
		return dir.findElement(By.xpath("//input[@ng-model='user.firstName']"));
	}
	
	public static WebElement LastName(WebDriver dir)
	{
		return dir.findElement(By.xpath("//input[@ng-model='user.lastName']"));
	}
	
	public static WebElement PinCode(WebDriver dir)
	{
		return dir.findElement(By.xpath("//input[@ng-model='user.pincode']"));
	}
	
	public static WebElement Email(WebDriver dir)
	{
		return dir.findElement(By.xpath("//input[@ng-model='user.email']"));
	}
	
	public static WebElement Mobile(WebDriver dir)
	{
		return dir.findElement(By.xpath("//input[@ng-model='user.mobile']"));
	}
	
	
	public static WebElement AcceptConditionRadioButton(WebDriver dir)
	{
		return dir.findElement(By.xpath("//input[@ng-model='acceptCondition']"));
	}
	
	
	public static WebElement RegisterButton(WebDriver dir)
	{
		return dir.findElement(By.xpath("//a[@ng-disabled='form.$invalid']"));
	}
	
	
	
	
	
	
	
	
}
