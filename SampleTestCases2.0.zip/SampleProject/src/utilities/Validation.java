package utilities;

import org.testng.Assert;

public class Validation {

	public static boolean NameValidation(String str)
	{
		String Name_REGEX = "^[a-z A-Z]+$";
	      
		return str.matches(Name_REGEX);
		
	}
	
	public static boolean OtpValidation(String str)
	{
		String otpStr="123456";;
		if(otpStr.equals(str))
			return true;
		else
			return false;
				
	}
	public static boolean PincodeValidation(String str)
	{
		String Pin_REGEX ="^([1-9])([0-9]){5}$";
		return str.matches(Pin_REGEX);
	}
	
	
	public static boolean EmailidValidation(String emailStr)
	{
		String EMAIL_REGEX = "^[\\w-_\\.+]*[\\w-_\\.]\\@([\\w]+\\.)+[\\w]+[\\w]$";
	      
	    return emailStr.matches(EMAIL_REGEX);
		
	}
	
	
	public static boolean MobileNoValidation(String mob_no)
	{
		String MOBILE_REGEX="^(\\+91[\\-\\s]?)?[0]?(91)?[789]\\d{9}$";
		return mob_no.matches(MOBILE_REGEX);
	}
	
	
	
	
	
	
}
