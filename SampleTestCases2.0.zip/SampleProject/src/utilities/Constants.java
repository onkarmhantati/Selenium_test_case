package utilities;

public class Constants {

}
