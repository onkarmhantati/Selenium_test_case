package utilities;

import org.openqa.selenium.WebDriver;

public class Browser {
	WebDriver driver; 

	public static void start(WebDriver driver_local)
	{
		driver_local.get("http://dev.transporto.in/#/core/login");
		
		driver_local.manage().window().maximize();
	}
	
	public static void close(WebDriver driver_local)
	{
		driver_local.close();
	}
	
	
}
