package POM;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.testng.annotations.Test;

import utilities.Browser;

public class Home {

	public static WebElement QuickRegisterButton(WebDriver dir)
	{
		return dir.findElement(By.xpath("//a[@href='#/core/signup']"));
	}
}
