package testScripts;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.testng.Assert;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import POM.Home;
import POM.Register;
import utilities.Browser;
import utilities.Validation;

public class FieldValidationTestCase {

WebDriver driver=new FirefoxDriver();
	
	@BeforeMethod
	public void setUp()
	{
		Browser.start(driver);

	    driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);

		
		System.out.println("Test Case start.");
	}
	
	@AfterMethod
	public void tearDown()
	{
		System.out.println("Test Case End.");
		
		//Browser.close(driver);
	}
	
	@Test
	public void CompulsoryField() throws InterruptedException
	{
		Home.QuickRegisterButton(driver).click();
		Thread.sleep(2000);
		Register.CustomerRadioButton(driver).click();
		Register.FirstName(driver).sendKeys("Sabc");
		Register.LastName(driver).sendKeys("xIiz");
		Register.PinCode(driver).sendKeys("413006");
		Register.Email(driver).sendKeys("asmy25kgd@qwe.com");
		Register.Mobile(driver).sendKeys("9867277511");
		Register.AcceptConditionRadioButton(driver).click();
		
		
		
		String firstName=Register.FirstName(driver).getAttribute("value");
		String lastName=Register.LastName(driver).getAttribute("value");
		String pincode_no=Register.PinCode(driver).getAttribute("value");
		String email=Register.Email(driver).getAttribute("value");
		String mobile_no=Register.Mobile(driver).getAttribute("value");
				
		FieldValidation(firstName,lastName,pincode_no,email,mobile_no);
		
		Thread.sleep(2000);
		Register.RegisterButton(driver).click();
		
		Register.RegisterOtp(driver).sendKeys("123456");
		String otp=Register.RegisterOtp(driver).getAttribute("value");
		OtpValidation(otp);
		Register.RegisterButton(driver).click();
		
		System.out.println("Registration done");
				
		
		
	}
	public void OtpValidation(String otpStr)
	{
		if(Validation.PincodeValidation(otpStr))
		{
			System.out.println("valid Otp");
		}
		else
		{
			System.out.println("only digit, Invalid Otp");
			Assert.assertTrue(false);
		}
		if(otpStr.length()!=6)
		{
			System.out.println("6 Digit Otp Please");
			Assert.assertTrue(false);
		}
		else
		{
			if(Validation.OtpValidation(otpStr))
			{
				System.out.println(" OTP match ");
			}
			else
			{
				System.out.println(" OTP not match");
				Assert.assertTrue(false);
			}
		}
	}
	public void FieldValidation(String firstN,String lastN,String pincode,String email_id,String mob_no)
	{

		if(firstN.length()<=0)
		{
			System.out.println("First name is compulsory!");
			Assert.assertTrue(false);
		}
		else
		{
			if(Validation.NameValidation(firstN))
			{
				System.out.println("Valid first Name");
				
			}
			else
			{
				System.out.println("Invalid first Name");
				Assert.assertTrue(false);
			}
		}
		if(lastN.length()<=0)
		{
			System.out.println("Last name is compulsory!");
			Assert.assertTrue(false);
		}
		else
		{
			if(Validation.NameValidation(lastN))
			{
				System.out.println("Valid last Name");
				
			}
			else
			{
				System.out.println("Invalid last Name");
				Assert.assertTrue(false);
			}
		}
		
		if(pincode.length()<=0)
		{
			System.out.println("Pin code is compulsory!");
			Assert.assertTrue(false);
		}
		else
		{
			if(Validation.PincodeValidation(pincode))
			{
				System.out.println("Valid pincode");
				
			}
			else
			{
				System.out.println("Invalid pincode");
				Assert.assertTrue(false);
			}
		}
		
		if(Validation.EmailidValidation(email_id))
		{
			System.out.println("Valid email-id");
			
		}
		else
		{
			System.out.println("Invalid email-id");
			Assert.assertTrue(false);
		}
		if(mob_no.length()<=0)
		{
			System.out.println("Mobile No is compulsory!");
			Assert.assertTrue(false);
		}
		else
		{
			if(Validation.MobileNoValidation(mob_no))
		{
			System.out.println("Valid mobile-no");
			
		}
		 else
		 {
			System.out.println("Invalid mobile-no");
			Assert.assertTrue(false);
		 }
		}
	}
	
		
		
		
		
		
		
		
	}
	
