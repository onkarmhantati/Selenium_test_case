package testScripts;

import java.util.concurrent.TimeUnit;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.testng.Assert;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import POM.Home;
import POM.Register;
import utilities.Browser;

public class MobileNoTest {

WebDriver driver=new FirefoxDriver();
	
	@BeforeMethod
	public void setUp()
	{
		Browser.start(driver);

	    driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);

		
		System.out.println("Test Case start.");
	}
	
	@AfterMethod
	public void tearDown()
	{
		System.out.println("Test Case End.");
		
		Browser.close(driver);
	}
	
	@Test
	public void validMobile_NoTest() throws InterruptedException
	{
		
	    Home.QuickRegisterButton(driver).click();
		Thread.sleep(2000);
		Register.Mobile(driver).sendKeys("90");
		
		String mob_no=Register.Mobile(driver).getAttribute("value");
		if(mobileTest(mob_no))
		{
			System.out.println("Valid Mobile No.");
		}
		else
		{
			System.out.println("Invalid Mobile No");
			Assert.assertTrue(false);
		}
	}
	public boolean mobileTest(String mobile_no) {
        
        Pattern pattern = Pattern.compile("^[789]\\d{9}$");
        Matcher matcher = pattern.matcher(mobile_no);

        if (matcher.matches()){
           return true;
        }
        else{
            return false;
        }       
    }
}
