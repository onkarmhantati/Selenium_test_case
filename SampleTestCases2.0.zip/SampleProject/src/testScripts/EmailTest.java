package testScripts;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.testng.Assert;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import POM.Home;
import POM.Register;
import utilities.Browser;

public class EmailTest {
WebDriver driver=new FirefoxDriver();
	
	@BeforeMethod
	public void setUp()
	{
		Browser.start(driver);

	    driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);

		
		System.out.println("Test Case start.");
	}
	
	@AfterMethod
	public void tearDown()
	{
		System.out.println("Test Case End.");
		
		//Browser.close(driver);
	}
	
	@Test
	public void validEmailTest() throws InterruptedException
	{
		
	    Home.QuickRegisterButton(driver).click();
		Thread.sleep(2000);
		Register.CustomerRadioButton(driver).click();
		Register.FirstName(driver).sendKeys("abc");
		Register.LastName(driver).sendKeys("xyz");
		Register.PinCode(driver).sendKeys("416005");
		Register.Email(driver).sendKeys("asd@qwe");
		Register.Mobile(driver).sendKeys("1234567890");
		Register.AcceptConditionRadioButton(driver).click();
		
		
		String email=Register.Email(driver).getAttribute("value");
		if(emailtest(email))
		{
			System.out.println("Valid Email Id");
		}
		else
		{
			System.out.println("Invalid Email id");
			Assert.assertTrue(false);
		}
		
		
	}
	public boolean emailtest(String email_id)
	{
			String EMAIL_REGEX = "^[\\w-_\\.+]*[\\w-_\\.]\\@([\\w]+\\.)+[\\w]+[\\w]$";
		      
		    return email_id.matches(EMAIL_REGEX);
		      
	
	}

}
